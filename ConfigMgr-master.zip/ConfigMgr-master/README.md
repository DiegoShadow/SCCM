# ConfigMgr
System Center Configuration Manager scripts

Scripts are provided as is with no liability and should be tested in a controlled environment.
